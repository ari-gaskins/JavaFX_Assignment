package com.example.adg_p02;
/**
 //***********************************************************************
 'Project: JavaFX_Assignment #1
 'Programmer: Ari Gaskins
 'Company Info:  arigaskins.work@gmail.com, arigaskins.tech@gmail.com
 'Date: 11 10 2023
 'Description:  Problem Number #2.
 '
 '   Application to allow user to calculate the cost
 '   to register for their conference event and any
 '   optional events or workshops available.
 '
 '--------------------------------------------------------------------------
 '   				HONOR CODE:
 '	I pledge that this program represents my own program code, I have received
 '	help from no one and I have given help to no one.
 '-----------------------------------------------------------------------------
 '
 '  LINE LENGTH - AVOID LINES LONGER THAN 80 CHARACTERS
 '  SCALE BELOW IS TO CALIBRATE SCREENSHOTS
 '  DO NOT HAVE YOUR CODE OR SCREENSHOT EXTEND BEYOND THE SCALE
 0........1.........2.........3.........4.........5.........6.........7.........8
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 */

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.paint.Color;

import java.util.ArrayList;

/**
 * JavaFX GUI to calculate the pricing for a
 * conference and optional preconference events.
 * @author Ari Gaskins
 */
public class ConferencePricingFX extends Application{

    /**
     * Setup GUI for conference cost calculator
     * @param stage
     */
    @Override
    public void start(Stage stage) {
        // vertical layout box to contain required items
        VBox requiredItems;
        // toggle group to get single selected value of radio button
        ToggleGroup requiredGroup;
        // radio button to choose general conference
        RadioButton generalConference;
        // radio button to choose student conference
        RadioButton studentConference;
        // label for required items box
        Label requiredLabel;

        // check tree values
        // vertical layout box to contain optional items
        VBox optionalItems;
        // checkbox for dinner and keynote speech
        CheckBox dinnerKeynote;
        // checkbox for e-commerce workshop
        CheckBox ecommerceWorkshop;
        // checkbox for the future of the web workshop
        CheckBox futureOfWebWorkshop;
        // checkbox for advanced java workshop
        CheckBox javaWorkshop;
        // checkbox for network security workshop
        CheckBox networkWorkshop;
        // label for optional items box
        Label optionalLabel;

        // conference fee amount
        final double[] conferenceFee = new double[1];
        // total optional fees
        final double[] totalOptional = new double[1];
        // optional fees amount
        final ArrayList<Double> optionalFees;
        // total cost of all selected values
        final double[] totalCost = new double[1];

        // submit button and total cost HBox
        HBox submitItems;
        // label for total cost of all selected values
        Label totalCostLabel;
        // total cost text field display
        TextField totalCostField;
        // submit button to trigger calculation
        Button submitButton;

        // collection of form components
        Scene formScene;
        // create 2-D grid for scene components
        GridPane gridPane;
        // object containing padding for gridPane
        Insets gridPadding;

        // color for background
        Color bgColor;
        // border radius for pane
        CornerRadii paneRadius;
        // background fill for gridpane background
        BackgroundFill paneBgFill;
        // background for gridpane
        Background paneBg;
        // padding for gridpane background
        Insets bgPadding;

        // color for vboxes
        Color vbColor;
        // border radius for vboxes
        CornerRadii vbRadius;
        // background for vboxes' backgrounds
        BackgroundFill vbBgFill;
        // background for vboxes
        Background vbBg;
        // padding for vboxes' background
        Insets vbPadding;

        // Initialize required section
        requiredItems = new VBox(10);
        requiredGroup = new ToggleGroup();
        generalConference = new RadioButton("General Admission ($895)");
        studentConference = new RadioButton("Student Admission ($495)");
        requiredLabel = new Label(
                "*Required* Please select conference registration type:"
        );

        // Initialize conference fee
        conferenceFee[0] = 0;

        // setup radio button selection for required items
        // allow ToggleGroup to get selection from buttons
        generalConference.setToggleGroup(requiredGroup);
        studentConference.setToggleGroup(requiredGroup);
        requiredItems.getChildren().addAll(
                requiredLabel, generalConference, studentConference
        );

        // Initialize optional section items
        optionalItems = new VBox(10);
        dinnerKeynote = new CheckBox(
                "Dinner and Keynote Speech ($30)"
        );
        ecommerceWorkshop = new CheckBox(
                "Workshop: Introduction to E-Commerce ($295)"
        );
        futureOfWebWorkshop = new CheckBox(
                "Workshop: The Future of the Web ($295)"
        );
        javaWorkshop = new CheckBox(
                "Workshop: Advanced Java Programming ($395)"
        );
        networkWorkshop = new CheckBox(
                "Workshop: Network Security ($395)"
        );
        optionalLabel = new Label(
                "[Optional] Select which pre-conference" +
                " events you will be attending:"
        );
        optionalItems.getChildren().addAll(
                optionalLabel, dinnerKeynote,
                ecommerceWorkshop, futureOfWebWorkshop,
                javaWorkshop, networkWorkshop
        );
        // Initialize optional fees array
        optionalFees = new ArrayList<Double>();

        // Initialize submit section items
        submitItems = new HBox(10);
        totalCostLabel = new Label("Total Cost:");
        totalCostField = new TextField();
        submitButton = new Button("Submit");

        // set total cost items invisible
        totalCostLabel.setVisible(false);
        totalCostField.setVisible(false);
        totalCostField.setEditable(false);

        // add items to submission HBox
        submitItems.getChildren().addAll(
                submitButton, totalCostLabel, totalCostField
        );

        // setup scene padding
        gridPadding = new Insets(15, 10, 10, 15);
        gridPane = new GridPane();
        gridPane.setPadding(gridPadding);
        gridPane.setHgap(30);
        gridPane.setVgap(10);

        // add components to pane
        gridPane.add(requiredItems, 0, 0);
        gridPane.add(optionalItems, 0, 1);
        gridPane.add(submitItems, 0, 2);

        // prettify the gridpane
        bgColor = Color.web("#3669AD");
        paneRadius = CornerRadii.EMPTY;
        bgPadding = new Insets(0);
        paneBgFill = new BackgroundFill(
                bgColor, paneRadius, bgPadding
        );
        paneBg = new Background(paneBgFill);
        gridPane.setBackground(paneBg);

        // prettify the VBox components
        vbColor = Color.WHITE;
        vbRadius = new CornerRadii(5);
        vbPadding = Insets.EMPTY;
        vbBgFill = new BackgroundFill(
                vbColor, vbRadius, vbPadding
        );
        vbBg = new Background(vbBgFill);
        requiredItems.setBackground(vbBg);
        optionalItems.setBackground(vbBg);
        requiredItems.setPadding(
                new Insets(10, 10, 15, 10)
        );
        optionalItems.setPadding(
                new Insets(10, 10, 15, 10)
        );

        // prettify submit button and total cost Label
        submitButton.setBackground(
                new Background(
                        new BackgroundFill(
                                Color.web("#3669AD"),
                                CornerRadii.EMPTY,
                                Insets.EMPTY
                        )
                )
        );
        submitButton.setTextFill(Color.WHITE);
        submitButton.setBorder(
                new Border(
                        new BorderStroke(
                                Color.WHITE,
                                BorderStrokeStyle.SOLID,
                                new CornerRadii(5),
                                BorderWidths.DEFAULT
                        )
                )
        );
        totalCostLabel.setTextFill(Color.WHITE);


        // event listener for getting which radio button is selected
        requiredGroup.selectedToggleProperty().addListener(
            new ChangeListener<Toggle>() {
                @Override
                public void changed(
                        ObservableValue<? extends Toggle>
                                observableValue, Toggle toggle, Toggle t1
                ) {
                    RadioButton selectedOption =
                            (RadioButton) requiredGroup.getSelectedToggle();

                    // check radio button text to find selection
                    int generalSelection =
                            selectedOption.getText().compareTo(
                                    generalConference.getText()
                            );
                    int studentSelection =
                            selectedOption.getText().compareTo(
                                    studentConference.getText()
                            );

                    // set conferenceFee value based on selection type
                    if (generalSelection == 0) {
                        conferenceFee[0] = 895;
                    }

                    if (studentSelection == 0) {
                        conferenceFee[0] = 495;
                    }
            }
        });

        // event handler for submit button to show total
        // after checking what checkboxes are selected
        EventHandler<ActionEvent> submitEvent = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                double sum = 0;

                // Initialize fee values
                totalOptional[0] = 0;
                totalCost[0] = 0;

                // clear fees from any previous submissions
                optionalFees.clear();

                // check for selected checkboxes
                if (dinnerKeynote.isSelected()) {
                    optionalFees.add(30.0);
                }

                if (ecommerceWorkshop.isSelected()) {
                    optionalFees.add(295.0);
                }

                if (futureOfWebWorkshop.isSelected()) {
                    optionalFees.add(295.0);
                }

                if (javaWorkshop.isSelected()) {
                    optionalFees.add(395.0);
                }

                if (networkWorkshop.isSelected()) {
                    optionalFees.add(395.0);
                }

                // add up all optional fees
                for (double fee : optionalFees) {
                    sum += fee;
                }

                // update total optional fees
                totalOptional[0] = sum;

                // update total cost
                totalCost[0] = conferenceFee[0] + totalOptional[0];

                totalCostField.setText(String.format("%.2f", totalCost[0]));

                // make total cost visible
                totalCostLabel.setVisible(true);
                totalCostField.setVisible(true);
            }
        };

        // attach event handler to submit button
        submitButton.setOnAction(submitEvent);

        // set scene and stage
        formScene = new Scene(gridPane);
        stage.setTitle("Conference Registration Fees");
        stage.setScene(formScene);
        stage.setMinHeight(300);
        stage.setMinWidth(500);
        stage.show();
    }
    public static void main (String [] args){
        launch(args);
    }
}

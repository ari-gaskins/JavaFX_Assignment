module com.example.adg_p01 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.datatransfer;


    opens com.example.adg_p01 to javafx.fxml;
    exports com.example.adg_p01;
}
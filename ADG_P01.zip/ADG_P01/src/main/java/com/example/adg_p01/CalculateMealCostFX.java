package com.example.adg_p01;
/***********************************************************************
 'Project: JavaFX Assignment # 1
 'Programmer: Ari Gaskins
 'Company Info:  arigaskins.work@gmail.com, arigaskins.tech@gmail.com
 'Date: 10 10 2023
 'Description:  Problem Number # 1.
 '
 '   User enters their meal charge to the window. The program should calculate
 '   their sales tax (7%), gratuity/tip (18%), and the total cost
 '   of all items. The program should then output to the window the charges
 '   when the user presses the "Calculate" button.
 '
 '	--------------------------------------------------------------------------
 '   							HONOR CODE:
 '	I pledge that this program represents my own program code, I have received
 '	help from no one and I have given help to no one.
 '-----------------------------------------------------------------------------
 '
 '  LINE LENGTH - AVOID LINES LONGER THAN 80 CHARACTERS
 '  SCALE BELOW IS TO CALIBRATE SCREENSHOTS
 '  DO NOT HAVE YOUR CODE OR SCREENSHOT EXTEND BEYOND THE SCALE
 0........1.........2.........3.........4.........5.........6.........7.........8
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 */

import javafx.application.Application;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert.AlertType;


/**
 * Create FX application to display calculated meal costs.
 * Includes meal charge, taxes, gratuity/tips, & total cost.
 * @author Ari Gaskins
 */
public class CalculateMealCostFX extends Application {
    // declare GridPane object
    private GridPane gridPane;
    // declare Scene object
    private Scene scene;
    // declare meal charge Label object
    private Label mealChargeLabel;
    // declare tax Label object
    private Label taxLabel;
    // declare gratuity/tip Label object
    private Label gratuityLabel;
    // declare total cost Label object;
    private Label totalCostLabel;
    // declare meal charge TextField
    private TextField mealChargeField;
    // declare tax TextField object
    private TextField taxField;
    // declare gratuity TextField object
    private TextField gratuityField;
    // declare total cost TextField object
    private TextField totalCostField;

    /**
     * Create FX Application View.
     * @param applicationStage
     */
    @Override
    public void start(Stage applicationStage){
        // initialize new GridPane object
        gridPane = new GridPane();
        // initialize new Scene object
        scene = new Scene(gridPane);

        // initialize new Label objects
        mealChargeLabel = new Label("Meal Charge:");
        taxLabel = new Label("Tax Charge (7%):");
        gratuityLabel = new Label("Gratuity/Tips (18%):");
        totalCostLabel = new Label("Total Cost:");

        // initialize new TextField objects
        mealChargeField = new TextField();
        taxField = new TextField();
        gratuityField = new TextField();
        totalCostField = new TextField();

        // set meal charge text field width and make editable
        mealChargeField.setPrefColumnCount(15);
        mealChargeField.setEditable(true);

        // set field widths
        taxField.setPrefColumnCount(15);
        gratuityField.setPrefColumnCount(15);
        totalCostField.setPrefColumnCount(15);

        // make fields not editable
        taxField.setEditable(false);
        gratuityField.setEditable(false);
        totalCostField.setEditable(false);

        // initialize new Button object
        // declare calculate Button object
        Button calculateButton = new Button("Calculate");

        // position labels on grid pane
        gridPane.add(mealChargeLabel, 0, 0);
        gridPane.add(taxLabel, 0, 1);
        gridPane.add(gratuityLabel, 0, 2);
        gridPane.add(totalCostLabel, 0, 3);

        // position fields on grid pane
        gridPane.add(mealChargeField, 1, 0);
        gridPane.add(taxField, 1, 1);
        gridPane.add(gratuityField, 1, 2);
        gridPane.add(totalCostField, 1, 3);

        // position button on grid plane
        gridPane.add(calculateButton, 0, 4);

        // initialize new Insets object for padding
        // declare padding Insets object
        Insets gridPadding = new Insets(10, 10, 10, 10);
        // set padding
        gridPane.setPadding(gridPadding);
        // set spacing between columns
        gridPane.setHgap(10);
        //set spacing between rows
        gridPane.setVgap(10);

        // Set event handler on calculate button.
        // Calculate and add values to text fields.
        calculateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    // declare user string input
                    String userString;
                    // declare user input charge
                    double userCharge;
                    // declare tax for output
                    double tax;
                    // declare gratuity/tip for output
                    double gratuity;
                    // declare total cost for output
                    double totalCost;

                    userString = mealChargeField.getText();

                    // get user input as String, type cast to Double
                    userCharge = Double.parseDouble(userString);

                    // calculate tax based on input
                    tax = userCharge * 0.07;
                    // calculate gratuity/tip based on input
                    gratuity = userCharge * 0.18;
                    // calculate total cost by adding all values
                    totalCost = userCharge + tax + gratuity;

                    // check that input is non-negative
                    if (userCharge >= 0) {
                        // set text of fields to calculated results
                        // format results to dollar decimal format
                        mealChargeField.setText(String.format("%.2f", userCharge));
                        taxField.setText(String.format("%.2f", tax));
                        gratuityField.setText(String.format("%.2f", gratuity));
                        totalCostField.setText(String.format("%.2f", totalCost));
                    }
                    else {
                        // alert user if input is undesirable
                        Alert negativeAlert;
                        negativeAlert = new Alert(
                                AlertType.ERROR,
                                "Enter a positive number for cost."
                        );

                        // show alert, await user input on pane
                        negativeAlert.showAndWait();
                    }
                }
                catch (Exception e) {
                    // get errors
                    System.out.println("Internal Error Occurred: " +
                            e.getMessage());
                    // create default error for user
                    Alert invalidAlert;
                    invalidAlert = new Alert(
                            AlertType.ERROR,
                            "Invalid input. Enter numbers only."
                    );

                    invalidAlert.showAndWait();
                }
            }
        });

        // set scene on Stage object
        applicationStage.setScene(scene);
        // set window title
        applicationStage.setTitle("Meal Cost Calculator");
        // make window visible
        applicationStage.show();
    }
    public static void main(String[] args) {
        // launch JavaFX application
        launch(args);
    }
}
